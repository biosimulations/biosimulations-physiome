Temperature component
---------------------
The expressions for the :math:`\alpha` and :math:`\beta` in the gating rates components are scaled with a temperature factor :math:`\phi` . 
This factor is defined in `temperature_factor.cellml <../components/temperature_factor.cellml>`_, i.e., :math:`Q_{10}` of 3.
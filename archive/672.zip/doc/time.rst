Time component
--------------

It is often useful to separate time into its own component as it is used throughout the model and is usually one of the main variables to be managed when joining models together.
The `time.cellml <../experiments/time.cellml>`_ is put in the directory of `experiments`.
function g_ss = calc_gss(alpha,beta)
g_ss = alpha./(alpha + beta);
end
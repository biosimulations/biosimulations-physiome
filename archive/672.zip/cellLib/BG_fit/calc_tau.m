function tau = calc_tau(alpha,beta)
tau = 1./(alpha + beta);
end
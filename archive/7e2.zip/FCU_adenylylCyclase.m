tic;
[VOI, states, ALGEBRAIC, CONSTANTS, rates] = solvemodel();
toc;
                                                      

function [algebraicVariableCount] = getAlgebraicVariableCount()
    % Used later when setting a global variable with the number of algebraic variables.
    % Note: This is not the "main method".
    algebraicVariableCount =100;
end
% There are a total of 50 entries in each of the rate and state variable arrays.
% There are a total of 101 entries in the constant variable array.
%

function [VOI, states, ALGEBRAIC, CONSTANTS, rates] = solvemodel()
                    

    [LEGEND_STATES, LEGEND_ALGEBRAIC, legend_VOI, LEGEND_CONSTANTS] = createLegends();
                                                                     

    % create ALGEBRAIC of correct size
    global ALGEBRAICvariablecount;  ALGEBRAICvariablecount = getAlgebraicVariableCount();

    % change amoiunt of total givben chemical species available (labels) by a
    % multiplication factor (Gmult)
    labels = {'q_AC in component environment (fmol)', ...
        'q_cAMP in component environment (fmol)', ...
        'q_RB1 in component environment (fmol)', ...
        'q_Gs in component environment (fmol)', ...
        'q_RM2 in component environment (fmol)', ...
        'q_Gi in component environment (fmol)'};
%     labels = {'q_RB1_init in component environment (fmol)', ...
%         'q_R_M2_init in component environment (fmol)'};
    [igs,~,~] = find_indices(labels, cellstr(LEGEND_CONSTANTS), cellstr(LEGEND_STATES), cellstr(LEGEND_ALGEBRAIC));
    Gmult = 1; %1e3;
    [init_states, CONSTANTS] = initConsts(Gmult, igs);

    % ------------------------------------------
    % set timespan to solve over
    VOI = [0,1e-4]; % fast timescales due to fkc
%     VOI = [0 1e-3];
    % ------------------------------------------

    % set numerical accuracy options for ode solver
    options = odeset('reltol', 1e-07/3, 'abstol', 1e-07/3, 'maxstep', 1e-9); % step: 1e-4 % no need for step=1e-9. same as 1e-5

    % extra options for stimuli [ L_B1, L_M2 ] settings 
    p = struct;
%     p.stimtimes = [[1,20];[3,40]];
	p.stimthreshold = [-0.95, -0.95]; %[1e-3,1e-3];
    p.stimholding = [1e-9,1e-9];
    p.stimmag = [1.888e10,1.888e10]; %[1e6,1e6];
    p.stimstart = [1.2e-6,3e-6];
    p.trAMP = [1e-6,1e-6]; % seconds for rAMP start
    p.stimdur = [1,1];
    if true
        p.stimmag = [0,0];
    end
    p.freq = [1,1]; %[0.25,0.25]; % per second
    % solve model with ode solver
    [VOI, states] = ode15s(@(VOI, states)computeRates(VOI, states, CONSTANTS,p), VOI, init_states, options);

    % compute ALGEBRAIC variables
    [rates, ALGEBRAIC] = computeRates(VOI, states, CONSTANTS,p);
    ALGEBRAIC = computeAlgebraic(ALGEBRAIC, CONSTANTS, states, VOI,p);

    labels = {'q_LB1 in component environment (fmol)', ... 
                'q_LM2 in component environment (fmol)', ...
                'q_L_RB1_Gs in component environment (fmol)', ...
                'q_L_RM2_Gi in component environment (fmol)', ...
                'q_Gsa_GTP in component environment (fmol)', ...
                'q_Gia_GTP in component environment (fmol)', ...
                'q_Gsa_GTP_AC in component environment (fmol)', ...
                'q_AC in component environment (fmol)', ...
                'q_cAMP in component environment (fmol)', ...
                'q_ATP in component environment (fmol)'};
        
    if true
        [~, i_st, i_alg] = find_indices(labels, cellstr(LEGEND_CONSTANTS), cellstr(LEGEND_STATES), cellstr(LEGEND_ALGEBRAIC));
        plot_selected(i_st,VOI,states,legend_VOI,LEGEND_STATES,sprintf('LRB1\nGmult=%g', Gmult),ceil(sqrt(length(i_st))))
        plot_selected(i_alg,VOI,ALGEBRAIC,legend_VOI,LEGEND_ALGEBRAIC,sprintf('LRB1\nGmult=%g', Gmult),ceil(sqrt(length(i_alg))))
    end
      
    % plot chemostat concentrations: they should be constant, or machine
    % error order
    labels = {...
'LB1_T in component environment (fmol)',...
'RB1_T in component environment (fmol)',...
'Gs_T in component environment (fmol)',...
'adenosine_T in component environment (fmol)'
};
    
    % debug RB1_t
    if false
        labels = {'q_RB1 in component LRGbinding_B1AR (fmol)','q_RB1 in component GsProtein (fmol)'};
        [~, i_st, ~] = find_indices(labels, cellstr(LEGEND_CONSTANTS), cellstr(LEGEND_STATES), cellstr(LEGEND_ALGEBRAIC));
        plot_selected(i_st,VOI,states,legend_VOI,LEGEND_STATES,sprintf('RB1\nGmult=%g', Gmult),ceil(sqrt(length(i_st))))
    end
    
    % debug aGs_GTP and aGiGTP
    if false
        labels = {...
            'q_RB1GsP in component environment (fmol)',...
            'q_R_M2GiP in component environment (fmol)',...
            'q_Gsa_GTP in component environment (fmol)',...
            'q_Gia_GTP in component environment (fmol)',...
            'vphos_RB1Gs in component GsProtein (fmol_per_sec)',...
            'vphos_LRB1Gs in component GsProtein (fmol_per_sec)',...
            'vphos_R_M2Gi in component GiProtein (fmol_per_sec)',...
            'vphos_LR_M2Gi in component GiProtein (fmol_per_sec)',...
            'vact1_Gs in component GsProtein (fmol_per_sec)',...
            'vact2_Gs in component GsProtein (fmol_per_sec)',...
            'vact1_Gi in component GiProtein (fmol_per_sec)',...
            'vact2_Gi in component GiProtein (fmol_per_sec)',...
            'vhyd_Gs in component GsProtein (fmol_per_sec)',...
            'vhyd_Gi in component GiProtein (fmol_per_sec)',...
            'q_Gsa_GTP in component GsProtein (fmol)',...
            'q_Gia_GTP in component GiProtein (fmol)',...
            };
        [~, i_st, i_alg] = find_indices(labels, cellstr(LEGEND_CONSTANTS), cellstr(LEGEND_STATES), cellstr(LEGEND_ALGEBRAIC));
        plot_selected(i_alg,VOI,ALGEBRAIC,legend_VOI,LEGEND_ALGEBRAIC,sprintf('ag_GTP\nGmult=%g', Gmult),ceil(sqrt(length(i_alg))))
        plot_selected(i_st,VOI,states,legend_VOI,LEGEND_STATES,sprintf('ag_GTP\nGmult=%g', Gmult),ceil(sqrt(length(i_st))))
    end
        
    % plot all q variables to confirm if we are ss
    if false
        figure();
        n = ceil(sqrt(size(states,2)));
        for i=1:size(states,2)
            subplot(n,n,i)
            plot(VOI, states(:,i));
            xlabel(legend_VOI);
            title(LEGEND_STATES(i,:));
        end
    end
end


function [] = plot_selected(ids,x,y,legend_x,legend_y,titlestr,ns)
    istart = 30;
    figure();
%     plot stimuli
    for i = 1:length(ids)
        subplot(ns,ns,i)
        plot(x(istart:end), y(istart:end,ids(i)));
        xlabel('time (s)');
        str = split(legend_y(ids(i),:), ' ');
        str = legend_y(ids(i),:);
        l = legend(str);
        set(l,'interpreter','none');
    end
    suptitle(titlestr)    
end

function [] = plot_2per(i_alg0,id0,ids,x,y0,y,legend_y,legend_y_con,titlestr,ns)
    istart = 30;
    figure();
%     plot 2 per subplot
    if i_alg0
        idoffset = length(i_alg0);
        for i = 1:idoffset
            subplot(ns,ns,i)
            plot(x(istart:end), y(istart:end,i_alg0(i)),'x-'); hold on;
            plot(x(istart:end), y(istart:end,ids(i)));
            xlabel('time (s)');
            diff = mean(abs(y(istart:end,i_alg0(i)) - y(istart:end,ids(i))));
            str = split(legend_y(i_alg0(i),:),' in');
            title([str(1), strcat('avg abs error = ', num2str(diff))]);
    %         legend('init','sumspecies');
            str1 = split(legend_y(i_alg0(i),:),' ');
            str2 = split(legend_y(ids(i),:),' ');
            legend(str1(1),str2(1));
        end
    else
        idoffset = 0;
    end
    for i = (idoffset+1):length(ids)
        subplot(ns,ns,i)
        plot(x(istart:end), ones(length(x)-istart+1,1)*y0(id0(i-idoffset)),'x-'); hold on;
        plot(x(istart:end), y(istart:end,ids(i)));
        diff = abs(mean(y(istart:end,ids(i))) - y0(id0(i-idoffset)));
        xlabel('time (s)');
        str = split(legend_y(ids(i),:),' in');
        title([str(1), strcat('avg abs error = ', num2str(diff))]);
        legend(legend_y_con(id0(i-idoffset),:),legend_y(ids(i),:));
    end
    suptitle(strcat(titlestr,' eps = ',num2str(eps)))    
end

function [i_con, i_st, i_alg] = find_indices(labels, LEGEND_CONSTANTS, LEGEND_STATES, LEGEND_ALGEBRAIC)
% return the indices for the selected labels
    all_legends = [LEGEND_CONSTANTS; LEGEND_STATES; LEGEND_ALGEBRAIC];
    
    i_con = [];
    for i = 1:length(labels)
        i_con = [i_con; find(strcmp(labels{i},LEGEND_CONSTANTS))];
    end
    i_st = [];
    for i = 1:length(labels)
        i_st = [i_st; find(strcmp(labels{i},LEGEND_STATES))];
    end
    i_alg = [];
    for i = 1:length(labels)
        i_alg = [i_alg; find(strcmp(labels{i},LEGEND_ALGEBRAIC))];
    end
    
    if length(i_con) + length(i_st) + length(i_alg) < length(labels)
        error('missing index');
    end
end

function [LEGEND_STATES, LEGEND_ALGEBRAIC, LEGEND_VOI, LEGEND_CONSTANTS] = createLegends()
    LEGEND_STATES = ''; LEGEND_ALGEBRAIC = ''; LEGEND_VOI = ''; LEGEND_CONSTANTS = '';
    LEGEND_CONSTANTS(:,1) = strpad('kappa_1a in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,2) = strpad('kappa_1b in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,3) = strpad('kappa_2a in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,4) = strpad('kappa_2b in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,5) = strpad('kappa_3a in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,6) = strpad('kappa_3b in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,7) = strpad('kappa_4a in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,8) = strpad('kappa_4b in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,9) = strpad('kappa_5 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,10) = strpad('kappa_6 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,11) = strpad('kappa_7 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,12) = strpad('kappa_GiAC in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,13) = strpad('kappa_Rswitch_B1 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,14) = strpad('kappa_LRswitch_B1 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,15) = strpad('kappa_C_B1 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,16) = strpad('kappa_RB1 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,17) = strpad('kappa_L_actR in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,18) = strpad('kappa_Act1_Gs in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,19) = strpad('kappa_Act2_Gs in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,20) = strpad('kappa_Hyd_Gs in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,21) = strpad('kappa_Reassoc_Gs in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,22) = strpad('kappa_InternRB1 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,23) = strpad('kappa_InternLRB1 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,24) = strpad('kappa_Rswitch_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,25) = strpad('kappa_LRswitch_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,26) = strpad('kappa_C_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,27) = strpad('kappa_R_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,28) = strpad('kappa_L_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,29) = strpad('kappa_Act1_Gi in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,30) = strpad('kappa_Act2_Gi in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,31) = strpad('kappa_Hyd_Gi in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,32) = strpad('kappa_Reassoc_Gi in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,33) = strpad('kappa_InternR_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,34) = strpad('kappa_InternLR_M2 in component BG_parameters (fmol_per_sec)');
    LEGEND_CONSTANTS(:,35) = strpad('K_ATP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,36) = strpad('K_cAMP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,37) = strpad('K_AC in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,38) = strpad('K_AC_ATP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,39) = strpad('K_Gsa_GTP_AC in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,40) = strpad('K_Gsa_GTP_AC_ATP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,41) = strpad('K_FSK_AC in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,42) = strpad('K_FSK_AC_ATP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,43) = strpad('K_PDE in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,44) = strpad('K_PDE_cAMP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,45) = strpad('K_five_AMP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,46) = strpad('K_IBMX in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,47) = strpad('K_PDEinh in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,48) = strpad('K_Gsa_GTP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,49) = strpad('K_FSK in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,50) = strpad('K_Gia_GTP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,51) = strpad('K_ACinh in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,52) = strpad('K_PPi in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,53) = strpad('K_RB1_inactive in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,54) = strpad('K_L_RB1_inactive in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,55) = strpad('K_LB1 in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,56) = strpad('K_RB1 in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,57) = strpad('K_Gs in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,58) = strpad('K_RB1_Gs in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,59) = strpad('K_L_RB1 in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,60) = strpad('K_L_RB1_Gs in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,61) = strpad('K_Gsbetagamma in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,62) = strpad('K_Gsa_GDP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,63) = strpad('K_GTP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,64) = strpad('K_GDP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,65) = strpad('K_Pi in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,66) = strpad('K_RB1_tag in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,67) = strpad('K_L_RB1_tag in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,68) = strpad('K_RB1_GRKArr in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,69) = strpad('K_L_RB1_GRKArr in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,70) = strpad('K_GRKArr in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,71) = strpad('K_RM2_inactive in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,72) = strpad('K_L_RM2_inactive in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,73) = strpad('K_LM2 in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,74) = strpad('K_RM2 in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,75) = strpad('K_Gi in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,76) = strpad('K_RM2_Gi in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,77) = strpad('K_L_RM2 in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,78) = strpad('K_L_RM2_Gi in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,79) = strpad('K_Gibetagamma in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,80) = strpad('K_Gia_GDP in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,81) = strpad('K_RM2_tag in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,82) = strpad('K_L_RM2_tag in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,83) = strpad('K_RM2_GRKArr in component BG_parameters (per_fmol)');
    LEGEND_CONSTANTS(:,84) = strpad('K_L_RM2_GRKArr in component BG_parameters (per_fmol)');
    LEGEND_VOI = strpad('time in component environment (second)');
    LEGEND_CONSTANTS(:,85) = strpad('vol_myo in component environment (pL)');
    LEGEND_CONSTANTS(:,86) = strpad('freq in component environment (dimensionless)');
    LEGEND_CONSTANTS(:,87) = strpad('stimSt1 in component environment (second)');
    LEGEND_CONSTANTS(:,88) = strpad('stimDur1 in component environment (second)');
    LEGEND_CONSTANTS(:,89) = strpad('tRamp1 in component environment (second)');
    LEGEND_CONSTANTS(:,90) = strpad('stimMag1 in component environment (fmol)');
    LEGEND_CONSTANTS(:,91) = strpad('stimHolding1 in component environment (fmol)');
    LEGEND_CONSTANTS(:,100) = strpad('m1 in component environment (fmol_per_sec)');
    LEGEND_CONSTANTS(:,92) = strpad('stimSt2 in component environment (second)');
    LEGEND_CONSTANTS(:,93) = strpad('stimDur2 in component environment (second)');
    LEGEND_CONSTANTS(:,94) = strpad('tRamp2 in component environment (second)');
    LEGEND_CONSTANTS(:,95) = strpad('stimMag2 in component environment (fmol)');
    LEGEND_CONSTANTS(:,96) = strpad('stimHolding2 in component environment (fmol)');
    LEGEND_CONSTANTS(:,101) = strpad('m2 in component environment (fmol_per_sec)');
    LEGEND_STATES(:,1) = strpad('q_ATP in component environment (fmol)');
    LEGEND_STATES(:,2) = strpad('q_AC in component environment (fmol)');
    LEGEND_STATES(:,3) = strpad('q_cAMP in component environment (fmol)');
    LEGEND_STATES(:,4) = strpad('q_AC_ATP in component environment (fmol)');
    LEGEND_STATES(:,5) = strpad('q_FSK in component environment (fmol)');
    LEGEND_STATES(:,6) = strpad('q_FSK_AC in component environment (fmol)');
    LEGEND_STATES(:,7) = strpad('q_FSK_AC_ATP in component environment (fmol)');
    LEGEND_STATES(:,8) = strpad('q_Gsa_GTP in component environment (fmol)');
    LEGEND_STATES(:,9) = strpad('q_Gsa_GTP_AC in component environment (fmol)');
    LEGEND_STATES(:,10) = strpad('q_Gsa_GTP_AC_ATP in component environment (fmol)');
    LEGEND_STATES(:,11) = strpad('q_PDE in component environment (fmol)');
    LEGEND_STATES(:,12) = strpad('q_PDEinh in component environment (fmol)');
    LEGEND_STATES(:,13) = strpad('q_PDE_cAMP in component environment (fmol)');
    LEGEND_STATES(:,14) = strpad('q_IBMX in component environment (fmol)');
    LEGEND_STATES(:,15) = strpad('q_five_AMP in component environment (fmol)');
    LEGEND_STATES(:,16) = strpad('q_Gia_GTP in component environment (fmol)');
    LEGEND_STATES(:,17) = strpad('q_ACinh in component environment (fmol)');
    LEGEND_STATES(:,18) = strpad('q_PPi in component environment (fmol)');
    LEGEND_STATES(:,19) = strpad('q_RB1_inactive in component environment (fmol)');
    LEGEND_STATES(:,20) = strpad('q_L_RB1_inactive in component environment (fmol)');
    LEGEND_STATES(:,21) = strpad('q_LB1_ode in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,4) = strpad('q_LB1_stim in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,6) = strpad('q_LB1 in component environment (fmol)');
    LEGEND_STATES(:,22) = strpad('q_RB1 in component environment (fmol)');
    LEGEND_STATES(:,23) = strpad('q_Gs in component environment (fmol)');
    LEGEND_STATES(:,24) = strpad('q_RB1_Gs in component environment (fmol)');
    LEGEND_STATES(:,25) = strpad('q_L_RB1 in component environment (fmol)');
    LEGEND_STATES(:,26) = strpad('q_L_RB1_Gs in component environment (fmol)');
    LEGEND_STATES(:,27) = strpad('q_Gsbetagamma in component environment (fmol)');
    LEGEND_STATES(:,28) = strpad('q_Gsa_GDP in component environment (fmol)');
    LEGEND_STATES(:,29) = strpad('q_GTP in component environment (fmol)');
    LEGEND_STATES(:,30) = strpad('q_GDP in component environment (fmol)');
    LEGEND_STATES(:,31) = strpad('q_Pi in component environment (fmol)');
    LEGEND_STATES(:,32) = strpad('q_RB1_tag in component environment (fmol)');
    LEGEND_STATES(:,33) = strpad('q_L_RB1_tag in component environment (fmol)');
    LEGEND_STATES(:,34) = strpad('q_RB1_GRKArr in component environment (fmol)');
    LEGEND_STATES(:,35) = strpad('q_L_RB1_GRKArr in component environment (fmol)');
    LEGEND_STATES(:,36) = strpad('q_GRKArr in component environment (fmol)');
    LEGEND_STATES(:,37) = strpad('q_RM2_inactive in component environment (fmol)');
    LEGEND_STATES(:,38) = strpad('q_L_RM2_inactive in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,8) = strpad('q_LM2 in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,5) = strpad('q_LM2_stim in component environment (fmol)');
    LEGEND_STATES(:,39) = strpad('q_LM2_ode in component environment (fmol)');
    LEGEND_STATES(:,40) = strpad('q_RM2 in component environment (fmol)');
    LEGEND_STATES(:,41) = strpad('q_Gi in component environment (fmol)');
    LEGEND_STATES(:,42) = strpad('q_RM2_Gi in component environment (fmol)');
    LEGEND_STATES(:,43) = strpad('q_L_RM2 in component environment (fmol)');
    LEGEND_STATES(:,44) = strpad('q_L_RM2_Gi in component environment (fmol)');
    LEGEND_STATES(:,45) = strpad('q_Gibetagamma in component environment (fmol)');
    LEGEND_STATES(:,46) = strpad('q_Gia_GDP in component environment (fmol)');
    LEGEND_STATES(:,47) = strpad('q_RM2_tag in component environment (fmol)');
    LEGEND_STATES(:,48) = strpad('q_L_RM2_tag in component environment (fmol)');
    LEGEND_STATES(:,49) = strpad('q_RM2_GRKArr in component environment (fmol)');
    LEGEND_STATES(:,50) = strpad('q_L_RM2_GRKArr in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,7) = strpad('LB1_T in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,1) = strpad('RB1_T in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,2) = strpad('Gs_T in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,3) = strpad('adenosine_T in component environment (fmol)');
    LEGEND_ALGEBRAIC(:,27) = strpad('v_1a in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,28) = strpad('v_1b in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,29) = strpad('v_2a in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,30) = strpad('v_2b in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,31) = strpad('v_3a in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,32) = strpad('v_3b in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,33) = strpad('v_4a in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,35) = strpad('v_4b in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,37) = strpad('v_5 in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,34) = strpad('v_6 in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,36) = strpad('v_7 in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,38) = strpad('v_GiAC in component cAMP (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,58) = strpad('v_Rswitch_B1 in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,59) = strpad('v_LRswitch_B1 in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,60) = strpad('v_C_B1 in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,61) = strpad('v_RB1 in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,62) = strpad('v_L_actR in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,63) = strpad('v_Act1_Gs in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,64) = strpad('v_Act2_Gs in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,66) = strpad('v_Hyd_Gs in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,67) = strpad('v_Reassoc_Gs in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,68) = strpad('v_InternRB1 in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,69) = strpad('v_InternLRB1 in component GPCRB1AR_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,89) = strpad('v_Rswitch_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,90) = strpad('v_LRswitch_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,91) = strpad('v_C_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,92) = strpad('v_R_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,93) = strpad('v_L_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,94) = strpad('v_Act1_Gi in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,95) = strpad('v_Act2_Gi in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,97) = strpad('v_Hyd_Gi in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,99) = strpad('v_Reassoc_Gi in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,98) = strpad('v_InternR_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,100) = strpad('v_InternLR_M2 in component GPCR_M2_reduced (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,65) = strpad('v_Rsynthesis_B1 in component environment (fmol_per_sec)');
    LEGEND_ALGEBRAIC(:,96) = strpad('v_Rsynthesis_M2 in component environment (fmol_per_sec)');
    LEGEND_CONSTANTS(:,97) = strpad('R in component constants (J_per_K_per_mol)');
    LEGEND_CONSTANTS(:,98) = strpad('T in component constants (kelvin)');
    LEGEND_CONSTANTS(:,99) = strpad('F in component constants (C_per_mol)');
    LEGEND_ALGEBRAIC(:,9) = strpad('mu_ATP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,10) = strpad('mu_cAMP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,11) = strpad('mu_AC in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,12) = strpad('mu_AC_ATP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,13) = strpad('mu_Gsa_GTP_AC in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,14) = strpad('mu_Gsa_GTP_AC_ATP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,15) = strpad('mu_FSK_AC in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,16) = strpad('mu_FSK_AC_ATP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,17) = strpad('mu_PDE in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,18) = strpad('mu_PDE_cAMP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,19) = strpad('mu_five_AMP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,20) = strpad('mu_IBMX in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,21) = strpad('mu_PDEinh in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,22) = strpad('mu_Gsa_GTP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,23) = strpad('mu_FSK in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,24) = strpad('mu_Gia_GTP in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,25) = strpad('mu_ACinh in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,26) = strpad('mu_PPi in component cAMP (J_per_mol)');
    LEGEND_ALGEBRAIC(:,39) = strpad('mu_RB1_inactive in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,40) = strpad('mu_L_RB1_inactive in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,41) = strpad('mu_LB1 in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,42) = strpad('mu_RB1 in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,43) = strpad('mu_Gs in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,44) = strpad('mu_RB1_Gs in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,45) = strpad('mu_L_RB1 in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,46) = strpad('mu_L_RB1_Gs in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,47) = strpad('mu_Gsa_GTP in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,48) = strpad('mu_Gsbetagamma in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,49) = strpad('mu_Gsa_GDP in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,50) = strpad('mu_GTP in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,51) = strpad('mu_GDP in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,52) = strpad('mu_Pi in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,53) = strpad('mu_RB1_tag in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,54) = strpad('mu_L_RB1_tag in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,55) = strpad('mu_RB1_GRKArr in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,56) = strpad('mu_L_RB1_GRKArr in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,57) = strpad('mu_GRKArr in component GPCRB1AR_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,70) = strpad('mu_RM2_inactive in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,71) = strpad('mu_L_RM2_inactive in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,72) = strpad('mu_LM2 in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,73) = strpad('mu_RM2 in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,74) = strpad('mu_Gi in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,75) = strpad('mu_RM2_Gi in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,76) = strpad('mu_L_RM2 in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,77) = strpad('mu_L_RM2_Gi in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,78) = strpad('mu_Gia_GTP in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,79) = strpad('mu_Gibetagamma in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,80) = strpad('mu_Gia_GDP in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,81) = strpad('mu_GTP in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,82) = strpad('mu_GDP in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,83) = strpad('mu_Pi in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,84) = strpad('mu_RM2_tag in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,85) = strpad('mu_L_RM2_tag in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,86) = strpad('mu_RM2_GRKArr in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,87) = strpad('mu_L_RM2_GRKArr in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_ALGEBRAIC(:,88) = strpad('mu_GRKArr in component GPCR_M2_reduced (J_per_mol)');
    LEGEND_RATES(:,1) = strpad('d/dt q_ATP in component environment (fmol)');
    LEGEND_RATES(:,2) = strpad('d/dt q_AC in component environment (fmol)');
    LEGEND_RATES(:,4) = strpad('d/dt q_AC_ATP in component environment (fmol)');
    LEGEND_RATES(:,3) = strpad('d/dt q_cAMP in component environment (fmol)');
    LEGEND_RATES(:,5) = strpad('d/dt q_FSK in component environment (fmol)');
    LEGEND_RATES(:,6) = strpad('d/dt q_FSK_AC in component environment (fmol)');
    LEGEND_RATES(:,7) = strpad('d/dt q_FSK_AC_ATP in component environment (fmol)');
    LEGEND_RATES(:,8) = strpad('d/dt q_Gsa_GTP in component environment (fmol)');
    LEGEND_RATES(:,9) = strpad('d/dt q_Gsa_GTP_AC in component environment (fmol)');
    LEGEND_RATES(:,10) = strpad('d/dt q_Gsa_GTP_AC_ATP in component environment (fmol)');
    LEGEND_RATES(:,13) = strpad('d/dt q_PDE_cAMP in component environment (fmol)');
    LEGEND_RATES(:,11) = strpad('d/dt q_PDE in component environment (fmol)');
    LEGEND_RATES(:,14) = strpad('d/dt q_IBMX in component environment (fmol)');
    LEGEND_RATES(:,12) = strpad('d/dt q_PDEinh in component environment (fmol)');
    LEGEND_RATES(:,15) = strpad('d/dt q_five_AMP in component environment (fmol)');
    LEGEND_RATES(:,16) = strpad('d/dt q_Gia_GTP in component environment (fmol)');
    LEGEND_RATES(:,17) = strpad('d/dt q_ACinh in component environment (fmol)');
    LEGEND_RATES(:,18) = strpad('d/dt q_PPi in component environment (fmol)');
    LEGEND_RATES(:,19) = strpad('d/dt q_RB1_inactive in component environment (fmol)');
    LEGEND_RATES(:,20) = strpad('d/dt q_L_RB1_inactive in component environment (fmol)');
    LEGEND_RATES(:,21) = strpad('d/dt q_LB1_ode in component environment (fmol)');
    LEGEND_RATES(:,22) = strpad('d/dt q_RB1 in component environment (fmol)');
    LEGEND_RATES(:,23) = strpad('d/dt q_Gs in component environment (fmol)');
    LEGEND_RATES(:,24) = strpad('d/dt q_RB1_Gs in component environment (fmol)');
    LEGEND_RATES(:,25) = strpad('d/dt q_L_RB1 in component environment (fmol)');
    LEGEND_RATES(:,26) = strpad('d/dt q_L_RB1_Gs in component environment (fmol)');
    LEGEND_RATES(:,27) = strpad('d/dt q_Gsbetagamma in component environment (fmol)');
    LEGEND_RATES(:,28) = strpad('d/dt q_Gsa_GDP in component environment (fmol)');
    LEGEND_RATES(:,29) = strpad('d/dt q_GTP in component environment (fmol)');
    LEGEND_RATES(:,30) = strpad('d/dt q_GDP in component environment (fmol)');
    LEGEND_RATES(:,31) = strpad('d/dt q_Pi in component environment (fmol)');
    LEGEND_RATES(:,32) = strpad('d/dt q_RB1_tag in component environment (fmol)');
    LEGEND_RATES(:,33) = strpad('d/dt q_L_RB1_tag in component environment (fmol)');
    LEGEND_RATES(:,34) = strpad('d/dt q_RB1_GRKArr in component environment (fmol)');
    LEGEND_RATES(:,35) = strpad('d/dt q_L_RB1_GRKArr in component environment (fmol)');
    LEGEND_RATES(:,36) = strpad('d/dt q_GRKArr in component environment (fmol)');
    LEGEND_RATES(:,37) = strpad('d/dt q_RM2_inactive in component environment (fmol)');
    LEGEND_RATES(:,38) = strpad('d/dt q_L_RM2_inactive in component environment (fmol)');
    LEGEND_RATES(:,39) = strpad('d/dt q_LM2_ode in component environment (fmol)');
    LEGEND_RATES(:,40) = strpad('d/dt q_RM2 in component environment (fmol)');
    LEGEND_RATES(:,41) = strpad('d/dt q_Gi in component environment (fmol)');
    LEGEND_RATES(:,42) = strpad('d/dt q_RM2_Gi in component environment (fmol)');
    LEGEND_RATES(:,43) = strpad('d/dt q_L_RM2 in component environment (fmol)');
    LEGEND_RATES(:,44) = strpad('d/dt q_L_RM2_Gi in component environment (fmol)');
    LEGEND_RATES(:,45) = strpad('d/dt q_Gibetagamma in component environment (fmol)');
    LEGEND_RATES(:,46) = strpad('d/dt q_Gia_GDP in component environment (fmol)');
    LEGEND_RATES(:,47) = strpad('d/dt q_RM2_tag in component environment (fmol)');
    LEGEND_RATES(:,48) = strpad('d/dt q_L_RM2_tag in component environment (fmol)');
    LEGEND_RATES(:,49) = strpad('d/dt q_RM2_GRKArr in component environment (fmol)');
    LEGEND_RATES(:,50) = strpad('d/dt q_L_RM2_GRKArr in component environment (fmol)');
    LEGEND_STATES  = LEGEND_STATES';
    LEGEND_ALGEBRAIC = LEGEND_ALGEBRAIC';
    LEGEND_RATES = LEGEND_RATES';
    LEGEND_CONSTANTS = LEGEND_CONSTANTS';
end

function [STATES, CONSTANTS] = initConsts(Gmult,igs)
    VOI = 0; CONSTANTS = []; STATES = []; ALGEBRAIC = [];
    CONSTANTS(:,1) = 6.19718e+06;
    CONSTANTS(:,2) = 0.00129391;
    CONSTANTS(:,3) = 176114;
    CONSTANTS(:,4) = 0.0475228;
    CONSTANTS(:,5) = 2.64321e+08;
    CONSTANTS(:,6) = 3.0735e-17;
    CONSTANTS(:,7) = 30960.9;
    CONSTANTS(:,8) = 0.119081;
    CONSTANTS(:,9) = 823.893;
    CONSTANTS(:,10) = 3191.74;
    CONSTANTS(:,11) = 479033;
    CONSTANTS(:,12) = 2417.47;
    CONSTANTS(:,13) = 1.02184;
    CONSTANTS(:,14) = 1.49856e-07;
    CONSTANTS(:,15) = 4082.77;
    CONSTANTS(:,16) = 5.98748e+06;
    CONSTANTS(:,17) = 4.27089e-08;
    CONSTANTS(:,18) = 0.000215226;
    CONSTANTS(:,19) = 167.999;
    CONSTANTS(:,20) = 0.00211433;
    CONSTANTS(:,21) = 3.99549e-05;
    CONSTANTS(:,22) = 0.892127;
    CONSTANTS(:,23) = 696367;
    CONSTANTS(:,24) = 241052;
    CONSTANTS(:,25) = 5.10328;
    CONSTANTS(:,26) = 97149.6;
    CONSTANTS(:,27) = 2.05674e+06;
    CONSTANTS(:,28) = 56.136;
    CONSTANTS(:,29) = 0.00220056;
    CONSTANTS(:,30) = 0.609877;
    CONSTANTS(:,31) = 1.60142;
    CONSTANTS(:,32) = 4.03024e-05;
    CONSTANTS(:,33) = 3.61714e-08;
    CONSTANTS(:,34) = 1.00248e-05;
    CONSTANTS(:,35) = 5.26836e-05;
    CONSTANTS(:,36) = 0.0157529;
    CONSTANTS(:,37) = 2.40711;
    CONSTANTS(:,38) = 4.49332;
    CONSTANTS(:,39) = 9.10781;
    CONSTANTS(:,40) = 5.19946;
    CONSTANTS(:,41) = 0.0606843;
    CONSTANTS(:,42) = 0.0945821;
    CONSTANTS(:,43) = 1.73264;
    CONSTANTS(:,44) = 1.22059;
    CONSTANTS(:,45) = 0.0157529;
    CONSTANTS(:,46) = 0.0197325;
    CONSTANTS(:,47) = 35.2834;
    CONSTANTS(:,48) = 0.274979;
    CONSTANTS(:,49) = 1.66559e-05;
    CONSTANTS(:,50) = 0.014522;
    CONSTANTS(:,51) = 12.0249;
    CONSTANTS(:,52) = 9.722e-05;
    CONSTANTS(:,53) = 28448.3;
    CONSTANTS(:,54) = 1.93985e+11;
    CONSTANTS(:,55) = 695517;
    CONSTANTS(:,56) = 284.483;
    CONSTANTS(:,57) = 0.000727564;
    CONSTANTS(:,58) = 234.964;
    CONSTANTS(:,59) = 0.193985;
    CONSTANTS(:,60) = 0.000301016;
    CONSTANTS(:,61) = 490.088;
    CONSTANTS(:,62) = 52.2185;
    CONSTANTS(:,63) = 10.6947;
    CONSTANTS(:,64) = 3.83436e-09;
    CONSTANTS(:,65) = 7.65396e-09;
    CONSTANTS(:,66) = 0.00642105;
    CONSTANTS(:,67) = 8.22611e-09;
    CONSTANTS(:,68) = 3.25848e-08;
    CONSTANTS(:,69) = 4.17449e-14;
    CONSTANTS(:,70) = 147520;
    CONSTANTS(:,71) = 0.00120595;
    CONSTANTS(:,72) = 56.963;
    CONSTANTS(:,73) = 124.828;
    CONSTANTS(:,74) = 1.20595e-05;
    CONSTANTS(:,75) = 7.21292;
    CONSTANTS(:,76) = 0.0897681;
    CONSTANTS(:,77) = 5.6963e-07;
    CONSTANTS(:,78) = 0.000323902;
    CONSTANTS(:,79) = 36.7999;
    CONSTANTS(:,80) = 689.431;
    CONSTANTS(:,81) = 1583.68;
    CONSTANTS(:,82) = 5.71425;
    CONSTANTS(:,83) = 80.3667;
    CONSTANTS(:,84) = 0.28998;
    CONSTANTS(:,85) = 34.4;
    CONSTANTS(:,86) = 500;
    CONSTANTS(:,87) = 3.5e-4;
    CONSTANTS(:,88) = 0.25e-4;
    CONSTANTS(:,89) = 1.8e-4;
    CONSTANTS(:,90) = 1e1;
    CONSTANTS(:,91) = 1e-5;
    CONSTANTS(:,92) = 7e-4;
    CONSTANTS(:,93) = 0.25e-4;
    CONSTANTS(:,94) = 1.8e-4;
    CONSTANTS(:,95) = 1e1;
    CONSTANTS(:,96) = 1e-5;
    STATES(:,1) = 190;
    STATES(:,2) = 1.889E-03;
    STATES(:,3) = 3.212E-02;
    STATES(:,4) = 1e-18;
    STATES(:,5) = 3.8e-5;
    STATES(:,6) = 1e-18;
    STATES(:,7) = 1e-18;
    STATES(:,8) = 0.01;
    STATES(:,9) = 1e-18;
    STATES(:,10) = 1e-18;
    STATES(:,11) = 1.482E-03;
    STATES(:,12) = 1e-18;
    STATES(:,13) = 1e-18;
    STATES(:,14) = 3.80E-06;
    STATES(:,15) = 1e-18;
    STATES(:,16) = 4.81E-04;
    STATES(:,17) = 1e-18;
    STATES(:,18) = 1e-18;
    STATES(:,19) = 0.0004579000e0;
    STATES(:,20) = 1e-18;
    STATES(:,21) = 0;
    STATES(:,22) = 1e-18;
    STATES(:,23) = 0.1455400000;
    STATES(:,24) = 1e-18;
    STATES(:,25) = 1e-18;
    STATES(:,26) = 1e-18;
    STATES(:,27) = 0.02;
    STATES(:,28) = 0.01;
    STATES(:,29) = 2.2;
    STATES(:,30) = 1.1;
    STATES(:,31) = 570;
    STATES(:,32) = 1e-18;
    STATES(:,33) = 1e-18;
    STATES(:,34) = 1e-18;
    STATES(:,35) = 1e-18;
    STATES(:,36) = 1e-3;
    STATES(:,37) = 0.00072162;
    STATES(:,38) = 1e-18;
    STATES(:,39) = 0;
    STATES(:,40) = 1e-18;
    STATES(:,41) = 0.00836;
    STATES(:,42) = 1e-18;
    STATES(:,43) = 1e-18;
    STATES(:,44) = 1e-18;
    STATES(:,45) = 1e-18;
    STATES(:,46) = 1e-18;
    STATES(:,47) = 1e-18;
    STATES(:,48) = 1e-18;
    STATES(:,49) = 1e-18;
    STATES(:,50) = 1e-18;
    CONSTANTS(:,97) = 8.31;
    CONSTANTS(:,98) = 310;
    CONSTANTS(:,99) = 96485;
    CONSTANTS(:,100) = CONSTANTS(:,90)./CONSTANTS(:,89);
    CONSTANTS(:,101) = CONSTANTS(:,95)./CONSTANTS(:,94);
    if (isempty(STATES)), warning('Initial values for states not set');, end
    % multiply constant values by Gmult, with indices given in igs
    for j=1:length(igs)
        CONSTANTS(:,igs(j)) = CONSTANTS(:,igs(j))*Gmult;
    end                    

end

function [RATES, ALGEBRAIC] = computeRates(VOI, STATES, CONSTANTS,p)
disp(VOI)
    global algebraicVariableCount;
    statesSize = size(STATES);
    statesColumnCount = statesSize(2);
    if ( statesColumnCount == 1)
        STATES = STATES';
        ALGEBRAIC = zeros(1, algebraicVariableCount);
        utilOnes = 1;
    else
        statesRowCount = statesSize(1);
        ALGEBRAIC = zeros(statesRowCount, algebraicVariableCount);
        RATES = zeros(statesRowCount, statesColumnCount);
        utilOnes = ones(statesRowCount, 1);
    end
    ALGEBRAIC(:,9) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,35).*STATES(:,1));
    ALGEBRAIC(:,11) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,37).*STATES(:,2));
    ALGEBRAIC(:,12) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,38).*STATES(:,4));
    ALGEBRAIC(:,27) =  CONSTANTS(:,1).*(exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,9))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,12)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,10) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,36).*STATES(:,3));
    ALGEBRAIC(:,26) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,52).*STATES(:,18));
    ALGEBRAIC(:,28) =  CONSTANTS(:,2).*(exp(ALGEBRAIC(:,12)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,10)+ALGEBRAIC(:,26))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,4) = ALGEBRAIC(:,27) - ALGEBRAIC(:,28);
    ALGEBRAIC(:,13) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,39).*STATES(:,9));
    ALGEBRAIC(:,14) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,40).*STATES(:,10));
    ALGEBRAIC(:,29) =  CONSTANTS(:,3).*(exp((ALGEBRAIC(:,13)+ALGEBRAIC(:,9))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,14)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,30) =  CONSTANTS(:,4).*(exp(ALGEBRAIC(:,14)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,13)+ALGEBRAIC(:,10)+ALGEBRAIC(:,26))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,10) = ALGEBRAIC(:,29) - ALGEBRAIC(:,30);
    ALGEBRAIC(:,15) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,41).*STATES(:,6));
    ALGEBRAIC(:,16) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,42).*STATES(:,7));
    ALGEBRAIC(:,31) =  CONSTANTS(:,5).*(exp((ALGEBRAIC(:,15)+ALGEBRAIC(:,9))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,16)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,1) = ( - ALGEBRAIC(:,27) - ALGEBRAIC(:,31)) - ALGEBRAIC(:,29);
    ALGEBRAIC(:,32) =  CONSTANTS(:,6).*(exp(ALGEBRAIC(:,16)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,15)+ALGEBRAIC(:,10)+ALGEBRAIC(:,26))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,7) = ALGEBRAIC(:,31) - ALGEBRAIC(:,32);
    ALGEBRAIC(:,17) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,43).*STATES(:,11));
    ALGEBRAIC(:,18) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,44).*STATES(:,13));
    ALGEBRAIC(:,33) =  CONSTANTS(:,7).*(exp((ALGEBRAIC(:,17)+ALGEBRAIC(:,10))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,18)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,3) = (ALGEBRAIC(:,28)+ALGEBRAIC(:,32)+ALGEBRAIC(:,30)) - ALGEBRAIC(:,33);
    ALGEBRAIC(:,22) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,48).*STATES(:,8));
    ALGEBRAIC(:,34) =  CONSTANTS(:,10).*(exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,22))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,13)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,9) = (ALGEBRAIC(:,34) - ALGEBRAIC(:,29))+ALGEBRAIC(:,30);
    ALGEBRAIC(:,23) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,49).*STATES(:,5));
    ALGEBRAIC(:,36) =  CONSTANTS(:,11).*(exp((ALGEBRAIC(:,23)+ALGEBRAIC(:,11))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,15)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,5) =  - ALGEBRAIC(:,36);
    RATES(:,6) = (ALGEBRAIC(:,36)+ALGEBRAIC(:,32)) - ALGEBRAIC(:,31);
    ALGEBRAIC(:,19) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,45).*STATES(:,15));
    ALGEBRAIC(:,35) =  CONSTANTS(:,8).*(exp(ALGEBRAIC(:,18)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,17)+ALGEBRAIC(:,19))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,13) = ALGEBRAIC(:,33) - ALGEBRAIC(:,35);
    RATES(:,15) = ALGEBRAIC(:,35);
    ALGEBRAIC(:,24) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,50).*STATES(:,16));
    ALGEBRAIC(:,25) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,51).*STATES(:,17));
    ALGEBRAIC(:,38) =  CONSTANTS(:,12).*(exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,24))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,25)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,2) = (((ALGEBRAIC(:,28) - ALGEBRAIC(:,27)) - ALGEBRAIC(:,34)) - ALGEBRAIC(:,36)) - ALGEBRAIC(:,38);
    ALGEBRAIC(:,20) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,46).*STATES(:,14));
    ALGEBRAIC(:,21) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,47).*STATES(:,12));
    ALGEBRAIC(:,37) =  CONSTANTS(:,9).*(exp((ALGEBRAIC(:,17)+ALGEBRAIC(:,20))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,21)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,11) = (ALGEBRAIC(:,35) - ALGEBRAIC(:,33)) - ALGEBRAIC(:,37);
    RATES(:,14) =  - ALGEBRAIC(:,37);
    RATES(:,12) = ALGEBRAIC(:,37);
    RATES(:,17) = ALGEBRAIC(:,38);
    RATES(:,18) = ALGEBRAIC(:,38);
    ALGEBRAIC(:,40) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,54).*STATES(:,20));
    ALGEBRAIC(:,45) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,59).*STATES(:,25));
    ALGEBRAIC(:,59) =  CONSTANTS(:,14).*(exp(ALGEBRAIC(:,40)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,45)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,20) =  - ALGEBRAIC(:,59);
%     ALGEBRAIC(:,4) = piecewise({VOI<CONSTANTS(:,87)&VOI>CONSTANTS(:,87) - CONSTANTS(:,89), CONSTANTS(:,91)+ CONSTANTS(:,100).*((VOI - CONSTANTS(:,87))+CONSTANTS(:,89)) , VOI>=CONSTANTS(:,87)&VOI<CONSTANTS(:,87)+CONSTANTS(:,88), CONSTANTS(:,90)+CONSTANTS(:,91) , VOI<CONSTANTS(:,87)+CONSTANTS(:,89)+CONSTANTS(:,88)&VOI>=CONSTANTS(:,87)+CONSTANTS(:,88), CONSTANTS(:,91)+  - CONSTANTS(:,100).*(((VOI - CONSTANTS(:,87)) - CONSTANTS(:,89)) - CONSTANTS(:,88)) }, CONSTANTS(:,91));
    m = p.stimmag(1)/p.trAMP(1);
    if VOI > p.stimstart
        j = 10;
    end
    ALGEBRAIC(:,4) = piecewise({VOI<p.stimstart(1)&VOI>p.stimstart(1) - p.trAMP(1), p.stimholding(1)+ m.*((VOI - p.stimstart(1))+p.trAMP(1)) , VOI>=p.stimstart(1)&VOI<p.stimstart(1)+p.stimdur(1), p.stimmag(1)+p.stimholding(1) , VOI<p.stimstart(1)+p.trAMP(1)+p.stimdur(1)&VOI>=p.stimstart(1)+p.stimdur(1), p.stimholding(1)+  - m.*(((VOI - p.stimstart(1)) - p.trAMP(1)) - p.stimdur(1)) }, p.stimholding(1));                        
    ALGEBRAIC(:,6) = ALGEBRAIC(:,4)+STATES(:,21);
    ALGEBRAIC(:,41) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,55).*ALGEBRAIC(:,6));
    ALGEBRAIC(:,42) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,56).*STATES(:,22));
    ALGEBRAIC(:,62) =  CONSTANTS(:,17).*(exp((ALGEBRAIC(:,42)+ALGEBRAIC(:,41))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,45)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,21) =  - ALGEBRAIC(:,62);
    ALGEBRAIC(:,39) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,53).*STATES(:,19));
    ALGEBRAIC(:,58) =  CONSTANTS(:,13).*(exp(ALGEBRAIC(:,39)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,42)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,43) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,57).*STATES(:,23));
    ALGEBRAIC(:,44) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,58).*STATES(:,24));
    ALGEBRAIC(:,60) =  CONSTANTS(:,15).*(exp((ALGEBRAIC(:,42)+ALGEBRAIC(:,43))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,44)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,22) = (ALGEBRAIC(:,58) - ALGEBRAIC(:,60)) - ALGEBRAIC(:,62);
    ALGEBRAIC(:,47) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,48).*STATES(:,8));
    ALGEBRAIC(:,48) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,61).*STATES(:,27));
    ALGEBRAIC(:,50) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,63).*STATES(:,29));
    ALGEBRAIC(:,51) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,64).*STATES(:,30));
    ALGEBRAIC(:,53) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,66).*STATES(:,32));
    ALGEBRAIC(:,63) =  CONSTANTS(:,18).*(exp((ALGEBRAIC(:,44)+ALGEBRAIC(:,50))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,47)+ALGEBRAIC(:,48)+ALGEBRAIC(:,53)+ALGEBRAIC(:,51))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,24) = ALGEBRAIC(:,60) - ALGEBRAIC(:,63);
    ALGEBRAIC(:,46) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,60).*STATES(:,26));
    ALGEBRAIC(:,61) =  CONSTANTS(:,16).*(exp((ALGEBRAIC(:,45)+ALGEBRAIC(:,43))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,46)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,25) = (ALGEBRAIC(:,59) - ALGEBRAIC(:,61))+ALGEBRAIC(:,62);
    ALGEBRAIC(:,65) = ALGEBRAIC(:,58)+ALGEBRAIC(:,62);
    RATES(:,19) =  - ALGEBRAIC(:,58)+ 0.000000.*ALGEBRAIC(:,65);
    ALGEBRAIC(:,54) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,67).*STATES(:,33));
    ALGEBRAIC(:,64) =  CONSTANTS(:,19).*(exp((ALGEBRAIC(:,46)+ALGEBRAIC(:,50))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,47)+ALGEBRAIC(:,48)+ALGEBRAIC(:,54)+ALGEBRAIC(:,51))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,26) = ALGEBRAIC(:,61) - ALGEBRAIC(:,64);
    ALGEBRAIC(:,49) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,62).*STATES(:,28));
    ALGEBRAIC(:,52) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,65).*STATES(:,31));
    ALGEBRAIC(:,66) =  CONSTANTS(:,20).*(exp(ALGEBRAIC(:,47)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,49)+ALGEBRAIC(:,52))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,8) = ( - ALGEBRAIC(:,34)+ALGEBRAIC(:,63)+ALGEBRAIC(:,64)) - ALGEBRAIC(:,66);
    ALGEBRAIC(:,67) =  CONSTANTS(:,21).*(exp((ALGEBRAIC(:,49)+ALGEBRAIC(:,48))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,43)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,23) = ( - ALGEBRAIC(:,60) - ALGEBRAIC(:,61))+ALGEBRAIC(:,67);
    RATES(:,27) = (ALGEBRAIC(:,63)+ALGEBRAIC(:,64)) - ALGEBRAIC(:,67);
    RATES(:,28) = ALGEBRAIC(:,66) - ALGEBRAIC(:,67);
    ALGEBRAIC(:,55) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,68).*STATES(:,34));
    ALGEBRAIC(:,57) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,70).*STATES(:,36));
    ALGEBRAIC(:,68) =  CONSTANTS(:,22).*(exp((ALGEBRAIC(:,53)+ALGEBRAIC(:,57))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,55)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,32) = ALGEBRAIC(:,63) - ALGEBRAIC(:,68);
    RATES(:,34) = ALGEBRAIC(:,68);
    ALGEBRAIC(:,56) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,69).*STATES(:,35));
    ALGEBRAIC(:,69) =  CONSTANTS(:,23).*(exp((ALGEBRAIC(:,54)+ALGEBRAIC(:,57))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,56)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,33) = ALGEBRAIC(:,64) - ALGEBRAIC(:,69);
    RATES(:,35) = ALGEBRAIC(:,69);
    ALGEBRAIC(:,71) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,72).*STATES(:,38));
    ALGEBRAIC(:,76) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,77).*STATES(:,43));
    ALGEBRAIC(:,90) =  CONSTANTS(:,25).*(exp(ALGEBRAIC(:,71)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,76)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,38) =  - ALGEBRAIC(:,90);
    ALGEBRAIC(:,70) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,71).*STATES(:,37));
    ALGEBRAIC(:,73) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,74).*STATES(:,40));
    ALGEBRAIC(:,89) =  CONSTANTS(:,24).*(exp(ALGEBRAIC(:,70)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,73)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
%     ALGEBRAIC(:,5) = piecewise({VOI<CONSTANTS(:,92)&VOI>CONSTANTS(:,92) - CONSTANTS(:,94), CONSTANTS(:,96)+ CONSTANTS(:,101).*((VOI - CONSTANTS(:,92))+CONSTANTS(:,94)) , VOI>=CONSTANTS(:,92)&VOI<CONSTANTS(:,92)+CONSTANTS(:,93), CONSTANTS(:,95)+CONSTANTS(:,96) , VOI<CONSTANTS(:,92)+CONSTANTS(:,94)+CONSTANTS(:,93)&VOI>=CONSTANTS(:,92)+CONSTANTS(:,93), CONSTANTS(:,96)+  - CONSTANTS(:,101).*(((VOI - CONSTANTS(:,92)) - CONSTANTS(:,94)) - CONSTANTS(:,93)) }, CONSTANTS(:,96));
    m = p.stimmag(2)/p.trAMP(2);
    ALGEBRAIC(:,5) = piecewise({VOI<p.stimstart(2)&VOI>p.stimstart(2) - p.trAMP(2), p.stimholding(2)+ m.*((VOI - p.stimstart(2))+p.trAMP(2)) , VOI>=p.stimstart(2)&VOI<p.stimstart(2)+p.stimdur(2), p.stimmag(2)+p.stimholding(2) , VOI<p.stimstart(2)+p.trAMP(2)+p.stimdur(2)&VOI>=p.stimstart(2)+p.stimdur(2), p.stimholding(2)+  - m.*(((VOI - p.stimstart(2)) - p.trAMP(2)) - p.stimdur(2)) }, p.stimholding(2));
    ALGEBRAIC(:,8) = ALGEBRAIC(:,5)+STATES(:,39);
    ALGEBRAIC(:,72) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,73).*ALGEBRAIC(:,8));
    ALGEBRAIC(:,93) =  CONSTANTS(:,28).*(exp((ALGEBRAIC(:,70)+ALGEBRAIC(:,72))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,71)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,37) =  - ALGEBRAIC(:,89) - ALGEBRAIC(:,93);
    RATES(:,39) =  - ALGEBRAIC(:,93);
    ALGEBRAIC(:,74) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,75).*STATES(:,41));
    ALGEBRAIC(:,75) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,76).*STATES(:,42));
    ALGEBRAIC(:,91) =  CONSTANTS(:,26).*(exp((ALGEBRAIC(:,73)+ALGEBRAIC(:,74))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,75)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,78) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,50).*STATES(:,16));
    ALGEBRAIC(:,79) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,79).*STATES(:,45));
    ALGEBRAIC(:,81) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,63).*STATES(:,29));
    ALGEBRAIC(:,82) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,64).*STATES(:,30));
    ALGEBRAIC(:,84) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,81).*STATES(:,47));
    ALGEBRAIC(:,94) =  CONSTANTS(:,29).*(exp((ALGEBRAIC(:,75)+ALGEBRAIC(:,81))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,78)+ALGEBRAIC(:,79)+ALGEBRAIC(:,84)+ALGEBRAIC(:,82))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,42) = ALGEBRAIC(:,91) - ALGEBRAIC(:,94);
    ALGEBRAIC(:,77) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,78).*STATES(:,44));
    ALGEBRAIC(:,92) =  CONSTANTS(:,27).*(exp((ALGEBRAIC(:,76)+ALGEBRAIC(:,74))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,77)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,43) = (ALGEBRAIC(:,90) - ALGEBRAIC(:,92))+ALGEBRAIC(:,93);
    ALGEBRAIC(:,85) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,82).*STATES(:,48));
    ALGEBRAIC(:,95) =  CONSTANTS(:,30).*(exp((ALGEBRAIC(:,77)+ALGEBRAIC(:,81))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,78)+ALGEBRAIC(:,79)+ALGEBRAIC(:,85)+ALGEBRAIC(:,82))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,29) = (( - ALGEBRAIC(:,63) - ALGEBRAIC(:,64)) - ALGEBRAIC(:,94)) - ALGEBRAIC(:,95);
    RATES(:,30) = ALGEBRAIC(:,63)+ALGEBRAIC(:,64)+ALGEBRAIC(:,94)+ALGEBRAIC(:,95);
    ALGEBRAIC(:,96) = (ALGEBRAIC(:,91))+ALGEBRAIC(:,93);
    RATES(:,40) = (ALGEBRAIC(:,89) - ALGEBRAIC(:,91))+ 1.00000.*ALGEBRAIC(:,96);
    RATES(:,44) = ALGEBRAIC(:,92) - ALGEBRAIC(:,95);
    ALGEBRAIC(:,80) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,80).*STATES(:,46));
    ALGEBRAIC(:,83) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,65).*STATES(:,31));
    ALGEBRAIC(:,97) =  CONSTANTS(:,31).*(exp(ALGEBRAIC(:,78)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,80)+ALGEBRAIC(:,83))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,16) = ( - ALGEBRAIC(:,38)+ALGEBRAIC(:,94)+ALGEBRAIC(:,95)) - ALGEBRAIC(:,97);
    RATES(:,31) = ALGEBRAIC(:,66)+ALGEBRAIC(:,97);
    ALGEBRAIC(:,86) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,83).*STATES(:,49));
    ALGEBRAIC(:,88) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,70).*STATES(:,36));
    ALGEBRAIC(:,98) =  CONSTANTS(:,33).*(exp((ALGEBRAIC(:,84)+ALGEBRAIC(:,88))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,86)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,47) = ALGEBRAIC(:,94) - ALGEBRAIC(:,98);
    RATES(:,49) = ALGEBRAIC(:,98);
    ALGEBRAIC(:,87) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,84).*STATES(:,50));
    ALGEBRAIC(:,100) =  CONSTANTS(:,34).*(exp((ALGEBRAIC(:,85)+ALGEBRAIC(:,88))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,87)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,36) = (( - ALGEBRAIC(:,68) - ALGEBRAIC(:,69)) - ALGEBRAIC(:,98)) - ALGEBRAIC(:,100);
    ALGEBRAIC(:,99) =  CONSTANTS(:,32).*(exp((ALGEBRAIC(:,80)+ALGEBRAIC(:,79))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,74)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    RATES(:,41) = ( - ALGEBRAIC(:,91) - ALGEBRAIC(:,92))+ALGEBRAIC(:,99);
    RATES(:,45) = (ALGEBRAIC(:,94)+ALGEBRAIC(:,95)) - ALGEBRAIC(:,99);
    RATES(:,46) = ALGEBRAIC(:,97) - ALGEBRAIC(:,99);
    RATES(:,48) = ALGEBRAIC(:,95) - ALGEBRAIC(:,100);
    RATES(:,50) = ALGEBRAIC(:,100);
   RATES = RATES';
end

% Calculate algebraic variables
function ALGEBRAIC = computeAlgebraic(ALGEBRAIC, CONSTANTS, STATES, VOI,p)
    statesSize = size(STATES);
    statesColumnCount = statesSize(2);
    if ( statesColumnCount == 1)
        STATES = STATES';
        utilOnes = 1;
    else
        statesRowCount = statesSize(1);
        utilOnes = ones(statesRowCount, 1);
    end
    ALGEBRAIC(:,9) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,35).*STATES(:,1));
    ALGEBRAIC(:,11) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,37).*STATES(:,2));
    ALGEBRAIC(:,12) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,38).*STATES(:,4));
    ALGEBRAIC(:,27) =  CONSTANTS(:,1).*(exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,9))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,12)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,10) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,36).*STATES(:,3));
    ALGEBRAIC(:,26) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,52).*STATES(:,18));
    ALGEBRAIC(:,28) =  CONSTANTS(:,2).*(exp(ALGEBRAIC(:,12)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,10)+ALGEBRAIC(:,26))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,13) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,39).*STATES(:,9));
    ALGEBRAIC(:,14) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,40).*STATES(:,10));
    ALGEBRAIC(:,29) =  CONSTANTS(:,3).*(exp((ALGEBRAIC(:,13)+ALGEBRAIC(:,9))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,14)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,30) =  CONSTANTS(:,4).*(exp(ALGEBRAIC(:,14)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,13)+ALGEBRAIC(:,10)+ALGEBRAIC(:,26))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,15) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,41).*STATES(:,6));
    ALGEBRAIC(:,16) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,42).*STATES(:,7));
    ALGEBRAIC(:,31) =  CONSTANTS(:,5).*(exp((ALGEBRAIC(:,15)+ALGEBRAIC(:,9))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,16)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,32) =  CONSTANTS(:,6).*(exp(ALGEBRAIC(:,16)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,15)+ALGEBRAIC(:,10)+ALGEBRAIC(:,26))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,17) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,43).*STATES(:,11));
    ALGEBRAIC(:,18) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,44).*STATES(:,13));
    ALGEBRAIC(:,33) =  CONSTANTS(:,7).*(exp((ALGEBRAIC(:,17)+ALGEBRAIC(:,10))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,18)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,22) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,48).*STATES(:,8));
    ALGEBRAIC(:,34) =  CONSTANTS(:,10).*(exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,22))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,13)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,23) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,49).*STATES(:,5));
    ALGEBRAIC(:,36) =  CONSTANTS(:,11).*(exp((ALGEBRAIC(:,23)+ALGEBRAIC(:,11))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,15)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,19) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,45).*STATES(:,15));
    ALGEBRAIC(:,35) =  CONSTANTS(:,8).*(exp(ALGEBRAIC(:,18)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,17)+ALGEBRAIC(:,19))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,24) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,50).*STATES(:,16));
    ALGEBRAIC(:,25) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,51).*STATES(:,17));
    ALGEBRAIC(:,38) =  CONSTANTS(:,12).*(exp((ALGEBRAIC(:,11)+ALGEBRAIC(:,24))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,25)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,20) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,46).*STATES(:,14));
    ALGEBRAIC(:,21) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,47).*STATES(:,12));
    ALGEBRAIC(:,37) =  CONSTANTS(:,9).*(exp((ALGEBRAIC(:,17)+ALGEBRAIC(:,20))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,21)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,40) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,54).*STATES(:,20));
    ALGEBRAIC(:,45) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,59).*STATES(:,25));
    ALGEBRAIC(:,59) =  CONSTANTS(:,14).*(exp(ALGEBRAIC(:,40)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,45)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
%     ALGEBRAIC(:,4) = piecewise({VOI<CONSTANTS(:,87)&VOI>CONSTANTS(:,87) - CONSTANTS(:,89), CONSTANTS(:,91)+ CONSTANTS(:,100).*((VOI - CONSTANTS(:,87))+CONSTANTS(:,89)) , VOI>=CONSTANTS(:,87)&VOI<CONSTANTS(:,87)+CONSTANTS(:,88), CONSTANTS(:,90)+CONSTANTS(:,91) , VOI<CONSTANTS(:,87)+CONSTANTS(:,89)+CONSTANTS(:,88)&VOI>=CONSTANTS(:,87)+CONSTANTS(:,88), CONSTANTS(:,91)+  - CONSTANTS(:,100).*(((VOI - CONSTANTS(:,87)) - CONSTANTS(:,89)) - CONSTANTS(:,88)) }, CONSTANTS(:,91));
    m = p.stimmag(1)/p.trAMP(1);
    ALGEBRAIC(:,4) = piecewise({VOI<p.stimstart(1)&VOI>p.stimstart(1) - p.trAMP(1), p.stimholding(1)+ m.*((VOI - p.stimstart(1))+p.trAMP(1)) , VOI>=p.stimstart(1)&VOI<p.stimstart(1)+p.stimdur(1), p.stimmag(1)+p.stimholding(1) , VOI<p.stimstart(1)+p.trAMP(1)+p.stimdur(1)&VOI>=p.stimstart(1)+p.stimdur(1), p.stimholding(1)+  - m.*(((VOI - p.stimstart(1)) - p.trAMP(1)) - p.stimdur(1)) }, p.stimholding(1));                        
    ALGEBRAIC(:,6) = ALGEBRAIC(:,4)+STATES(:,21);
    ALGEBRAIC(:,41) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,55).*ALGEBRAIC(:,6));
    ALGEBRAIC(:,42) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,56).*STATES(:,22));
    ALGEBRAIC(:,62) =  CONSTANTS(:,17).*(exp((ALGEBRAIC(:,42)+ALGEBRAIC(:,41))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,45)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,39) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,53).*STATES(:,19));
    ALGEBRAIC(:,58) =  CONSTANTS(:,13).*(exp(ALGEBRAIC(:,39)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,42)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,43) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,57).*STATES(:,23));
    ALGEBRAIC(:,44) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,58).*STATES(:,24));
    ALGEBRAIC(:,60) =  CONSTANTS(:,15).*(exp((ALGEBRAIC(:,42)+ALGEBRAIC(:,43))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,44)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,47) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,48).*STATES(:,8));
    ALGEBRAIC(:,48) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,61).*STATES(:,27));
    ALGEBRAIC(:,50) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,63).*STATES(:,29));
    ALGEBRAIC(:,51) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,64).*STATES(:,30));
    ALGEBRAIC(:,53) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,66).*STATES(:,32));
    ALGEBRAIC(:,63) =  CONSTANTS(:,18).*(exp((ALGEBRAIC(:,44)+ALGEBRAIC(:,50))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,47)+ALGEBRAIC(:,48)+ALGEBRAIC(:,53)+ALGEBRAIC(:,51))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,46) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,60).*STATES(:,26));
    ALGEBRAIC(:,61) =  CONSTANTS(:,16).*(exp((ALGEBRAIC(:,45)+ALGEBRAIC(:,43))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,46)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,65) = ALGEBRAIC(:,58)+ALGEBRAIC(:,62);
    ALGEBRAIC(:,54) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,67).*STATES(:,33));
    ALGEBRAIC(:,64) =  CONSTANTS(:,19).*(exp((ALGEBRAIC(:,46)+ALGEBRAIC(:,50))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,47)+ALGEBRAIC(:,48)+ALGEBRAIC(:,54)+ALGEBRAIC(:,51))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,49) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,62).*STATES(:,28));
    ALGEBRAIC(:,52) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,65).*STATES(:,31));
    ALGEBRAIC(:,66) =  CONSTANTS(:,20).*(exp(ALGEBRAIC(:,47)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,49)+ALGEBRAIC(:,52))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,67) =  CONSTANTS(:,21).*(exp((ALGEBRAIC(:,49)+ALGEBRAIC(:,48))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,43)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,55) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,68).*STATES(:,34));
    ALGEBRAIC(:,57) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,70).*STATES(:,36));
    ALGEBRAIC(:,68) =  CONSTANTS(:,22).*(exp((ALGEBRAIC(:,53)+ALGEBRAIC(:,57))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,55)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,56) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,69).*STATES(:,35));
    ALGEBRAIC(:,69) =  CONSTANTS(:,23).*(exp((ALGEBRAIC(:,54)+ALGEBRAIC(:,57))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,56)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,71) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,72).*STATES(:,38));
    ALGEBRAIC(:,76) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,77).*STATES(:,43));
    ALGEBRAIC(:,90) =  CONSTANTS(:,25).*(exp(ALGEBRAIC(:,71)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,76)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,70) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,71).*STATES(:,37));
    ALGEBRAIC(:,73) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,74).*STATES(:,40));
    ALGEBRAIC(:,89) =  CONSTANTS(:,24).*(exp(ALGEBRAIC(:,70)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,73)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
%     ALGEBRAIC(:,5) = piecewise({VOI<CONSTANTS(:,92)&VOI>CONSTANTS(:,92) - CONSTANTS(:,94), CONSTANTS(:,96)+ CONSTANTS(:,101).*((VOI - CONSTANTS(:,92))+CONSTANTS(:,94)) , VOI>=CONSTANTS(:,92)&VOI<CONSTANTS(:,92)+CONSTANTS(:,93), CONSTANTS(:,95)+CONSTANTS(:,96) , VOI<CONSTANTS(:,92)+CONSTANTS(:,94)+CONSTANTS(:,93)&VOI>=CONSTANTS(:,92)+CONSTANTS(:,93), CONSTANTS(:,96)+  - CONSTANTS(:,101).*(((VOI - CONSTANTS(:,92)) - CONSTANTS(:,94)) - CONSTANTS(:,93)) }, CONSTANTS(:,96));
      m = p.stimmag(2)/p.trAMP(2);
    ALGEBRAIC(:,5) = piecewise({VOI<p.stimstart(2)&VOI>p.stimstart(2) - p.trAMP(2), p.stimholding(2)+ m.*((VOI - p.stimstart(2))+p.trAMP(2)) , VOI>=p.stimstart(2)&VOI<p.stimstart(2)+p.stimdur(2), p.stimmag(2)+p.stimholding(2) , VOI<p.stimstart(2)+p.trAMP(2)+p.stimdur(2)&VOI>=p.stimstart(2)+p.stimdur(2), p.stimholding(2)+  - m.*(((VOI - p.stimstart(2)) - p.trAMP(2)) - p.stimdur(2)) }, p.stimholding(2));
    ALGEBRAIC(:,8) = ALGEBRAIC(:,5)+STATES(:,39);
    ALGEBRAIC(:,72) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,73).*ALGEBRAIC(:,8));
    ALGEBRAIC(:,93) =  CONSTANTS(:,28).*(exp((ALGEBRAIC(:,70)+ALGEBRAIC(:,72))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,71)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,74) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,75).*STATES(:,41));
    ALGEBRAIC(:,75) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,76).*STATES(:,42));
    ALGEBRAIC(:,91) =  CONSTANTS(:,26).*(exp((ALGEBRAIC(:,73)+ALGEBRAIC(:,74))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,75)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,78) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,50).*STATES(:,16));
    ALGEBRAIC(:,79) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,79).*STATES(:,45));
    ALGEBRAIC(:,81) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,63).*STATES(:,29));
    ALGEBRAIC(:,82) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,64).*STATES(:,30));
    ALGEBRAIC(:,84) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,81).*STATES(:,47));
    ALGEBRAIC(:,94) =  CONSTANTS(:,29).*(exp((ALGEBRAIC(:,75)+ALGEBRAIC(:,81))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,78)+ALGEBRAIC(:,79)+ALGEBRAIC(:,84)+ALGEBRAIC(:,82))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,77) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,78).*STATES(:,44));
    ALGEBRAIC(:,92) =  CONSTANTS(:,27).*(exp((ALGEBRAIC(:,76)+ALGEBRAIC(:,74))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,77)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,85) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,82).*STATES(:,48));
    ALGEBRAIC(:,95) =  CONSTANTS(:,30).*(exp((ALGEBRAIC(:,77)+ALGEBRAIC(:,81))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,78)+ALGEBRAIC(:,79)+ALGEBRAIC(:,85)+ALGEBRAIC(:,82))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,96) = (ALGEBRAIC(:,91))+ALGEBRAIC(:,93);
    ALGEBRAIC(:,80) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,80).*STATES(:,46));
    ALGEBRAIC(:,83) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,65).*STATES(:,31));
    ALGEBRAIC(:,97) =  CONSTANTS(:,31).*(exp(ALGEBRAIC(:,78)./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp((ALGEBRAIC(:,80)+ALGEBRAIC(:,83))./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,86) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,83).*STATES(:,49));
    ALGEBRAIC(:,88) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,70).*STATES(:,36));
    ALGEBRAIC(:,98) =  CONSTANTS(:,33).*(exp((ALGEBRAIC(:,84)+ALGEBRAIC(:,88))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,86)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,87) =  CONSTANTS(:,97).*CONSTANTS(:,98).*log( CONSTANTS(:,84).*STATES(:,50));
    ALGEBRAIC(:,100) =  CONSTANTS(:,34).*(exp((ALGEBRAIC(:,85)+ALGEBRAIC(:,88))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,87)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,99) =  CONSTANTS(:,32).*(exp((ALGEBRAIC(:,80)+ALGEBRAIC(:,79))./( CONSTANTS(:,97).*CONSTANTS(:,98))) - exp(ALGEBRAIC(:,74)./( CONSTANTS(:,97).*CONSTANTS(:,98))));
    ALGEBRAIC(:,1) = STATES(:,19)+STATES(:,20)+STATES(:,22)+STATES(:,24)+STATES(:,25)+STATES(:,26)+STATES(:,32)+STATES(:,33)+STATES(:,34)+STATES(:,35);
    ALGEBRAIC(:,2) = STATES(:,23)+STATES(:,24)+STATES(:,26)+STATES(:,8)+STATES(:,28);
    ALGEBRAIC(:,3) = STATES(:,3)+STATES(:,13)+STATES(:,15)+STATES(:,1)+STATES(:,4)+STATES(:,10)+STATES(:,7);
    ALGEBRAIC(:,7) = STATES(:,20)+ALGEBRAIC(:,6)+STATES(:,26)+STATES(:,25)+STATES(:,33)+STATES(:,35);
end

% Compute result of a piecewise function
function x = piecewise(cases, default)
    set = [0];
    for i = 1:2:length(cases)
        if (length(cases{i+1}) == 1)
            x(cases{i} & ~set,:) = cases{i+1};
        else
            x(cases{i} & ~set,:) = cases{i+1}(cases{i} & ~set);
        end
        set = set | cases{i};
        if(set), break, end
    end
    if (length(default) == 1)
        x(~set,:) = default;
    else
        x(~set,:) = default(~set);
    end
end

% Pad out or shorten strings to a set length
function strout = strpad(strin)
    req_length = 160;
    insize = size(strin,2);
    if insize > req_length
        strout = strin(1:req_length);
    else
        strout = [strin, blanks(req_length - insize)];
    end
end


Exponential decay: A simple first order ODE
-------------------------------------------

Used as the simplest example of a first order differential equation, this model consists of a `single equation <Firstorder.cellml/cellml_math>`_. One of the simulation experiments for this model described in the tutorial can be obtained by loading the `corresponding SED-ML document <Firstorder.sedml>`__ into OpenCOR and executing the simulation - which can be achived by choosing the **Launch with OpenCOR** link from the *Views Available* listing.
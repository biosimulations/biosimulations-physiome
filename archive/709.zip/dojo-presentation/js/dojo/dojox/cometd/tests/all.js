dojo.provide("dojox.cometd.tests.all");
dojo.require("dojox.cometd._base");

try{
	dojo.require("dojox.cometd.tests._base");
}catch(e){
	doh.debug(e);
}

dojo.provide("dojox.charting.tests.charting");

try{
	dojo.require("dojox.charting.tests.Theme");
}catch(e){
	doh.debug(e);
}

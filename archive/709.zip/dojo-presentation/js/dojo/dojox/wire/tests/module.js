dojo.provide("dojox.wire.tests.module");

try{
	dojo.require("dojox.wire.tests.wire");
	dojo.require("dojox.wire.tests.wireml");
}catch(e){
	doh.debug(e);
}


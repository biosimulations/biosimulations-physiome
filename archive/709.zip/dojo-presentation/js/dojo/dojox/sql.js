dojo.provide("dojox.sql"); 
dojo.require("dojox.sql._base");

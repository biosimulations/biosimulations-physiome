dojo.provide("dojox.off");
dojo.require("dojox.off._common");

dojo.provide("dojox.encoding.tests.encoding");

try{
	dojo.require("dojox.encoding.tests.ascii85");
	dojo.require("dojox.encoding.tests.easy64");
	dojo.require("dojox.encoding.tests.bits");
}catch(e){
	doh.debug(e);
}

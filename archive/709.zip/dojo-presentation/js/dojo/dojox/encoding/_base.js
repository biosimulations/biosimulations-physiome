dojo.provide("dojox.encoding._base");



dojo.provide("dojox.dtl.tests.module");

try{
	dojo.require("dojox.dtl.tests.text.filter");
	dojo.require("dojox.dtl.tests.text.tag");
	dojo.require("dojox.dtl.tests.html.tag");
	dojo.require("dojox.dtl.tests.html.buffer");
	dojo.require("dojox.dtl.tests.context");
}catch(e){
	doh.debug(e);
}
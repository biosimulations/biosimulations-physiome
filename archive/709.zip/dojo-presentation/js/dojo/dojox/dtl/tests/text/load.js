dojo.provide("dojox.dtl.tests.text.load");
// Test for the {% load %} tag
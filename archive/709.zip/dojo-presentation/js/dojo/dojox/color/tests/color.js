dojo.provide("dojox.color.tests.color");
dojo.require("dojox.color");

try{
	dojo.require("dojox.color.tests._base");
//	dojo.require("dojox.color.tests.Colorspace");
	dojo.require("dojox.color.tests.Palette");
//	dojo.require("dojox.color.tests.Generator");
}catch(e){
	doh.debug(e);
}

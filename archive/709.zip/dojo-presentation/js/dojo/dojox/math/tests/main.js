dojo.provide("dojox.math.tests.main");

try{
	// functional block
	dojo.require("dojox.math.tests.math");
}catch(e){
	doh.debug(e);
}

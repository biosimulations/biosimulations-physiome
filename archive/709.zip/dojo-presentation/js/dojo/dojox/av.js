dojo.provide("dojox.av");

dojo.require("dojox.av._base");

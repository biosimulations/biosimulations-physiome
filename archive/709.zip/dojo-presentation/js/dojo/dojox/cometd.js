// stub loader for the cometd module since no implementation code is allowed to live in top-level files
dojo.provide("dojox.cometd");
dojo.require("dojox.cometd._base");
dojo.require("dojox.cometd.longPollTransport");
dojo.require("dojox.cometd.callbackPollTransport");

({
next: "Seuraava",
previous: "Edellinen",
done: "Valmis"
})

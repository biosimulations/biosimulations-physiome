({
next: "Далее",
previous: "Назад",
done: "Готово"
})

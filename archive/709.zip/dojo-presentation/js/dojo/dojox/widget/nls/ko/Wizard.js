({
next: "다음",
previous: "이전",
done: "완료"
})

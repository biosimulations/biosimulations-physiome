({
next: "Volgende",
previous: "Vorige",
done: "Klaar"
})

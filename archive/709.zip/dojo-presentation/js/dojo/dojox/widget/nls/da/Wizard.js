({
next: "Næste",
previous: "Foregående",
done: "Udført"
})

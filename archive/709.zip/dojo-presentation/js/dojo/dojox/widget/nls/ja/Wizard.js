({
next: "次へ",
previous: "前へ",
done: "完了"
})

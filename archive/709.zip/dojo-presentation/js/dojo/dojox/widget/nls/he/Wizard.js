({
next: "הבא",
previous: "הקודם",
done: "סיום"
})

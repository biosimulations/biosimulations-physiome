({
next: "İleri",
previous: "Geri",
done: "Bitti"
})

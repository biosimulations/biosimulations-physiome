({
next: "Avançar",
previous: "Voltar",
done: "Concluído"
})

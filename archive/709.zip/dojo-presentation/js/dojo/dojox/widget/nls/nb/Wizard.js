({
next: "Neste",
previous: "Forrige",
done: "Ferdig"
})

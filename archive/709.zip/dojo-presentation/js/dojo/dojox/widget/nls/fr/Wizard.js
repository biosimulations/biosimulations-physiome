({
next: "Suivant",
previous: "Précédent",
done: "Terminé"
})

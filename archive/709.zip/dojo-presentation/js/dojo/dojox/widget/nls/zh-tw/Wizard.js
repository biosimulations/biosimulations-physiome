({
next: "下一步",
previous: "上一步",
done: "完成"
})

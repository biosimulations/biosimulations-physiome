({
next: "Weiter",
previous: "Zurück",
done: "Fertig"
})

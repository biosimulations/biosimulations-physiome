({
next: "Dalej",
previous: "Wstecz",
done: "Gotowe"
})

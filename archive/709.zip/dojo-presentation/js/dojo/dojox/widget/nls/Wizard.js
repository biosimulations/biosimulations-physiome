({
next: "Next",
previous: "Previous",
done: "Done"
})

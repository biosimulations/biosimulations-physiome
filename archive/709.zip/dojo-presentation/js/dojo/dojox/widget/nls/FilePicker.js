({
name: "Name",
path: "Path",
size: "Size (in bytes)"
})

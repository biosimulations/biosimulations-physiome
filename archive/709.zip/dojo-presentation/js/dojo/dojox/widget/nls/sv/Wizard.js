({
next: "Nästa",
previous: "Föregående",
done: "Stäng"
})

dojo.provide("dojox.validate");
dojo.require("dojox.validate._base"); 

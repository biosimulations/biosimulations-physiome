dojo.provide("dojox.html");
dojo.require("dojox.html.metrics");

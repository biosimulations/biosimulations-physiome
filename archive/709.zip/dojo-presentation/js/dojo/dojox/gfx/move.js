dojo.provide("dojox.gfx.move");

dojo.require("dojox.gfx.Mover");
dojo.require("dojox.gfx.Moveable");

dojo.provide("dojox.gfx.tests.module");

try{
	dojo.require("dojox.gfx.tests.matrix");
	dojo.require("dojox.gfx.tests.decompose");
}catch(e){
	doh.debug(e);
}


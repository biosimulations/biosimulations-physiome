dojo.provide("dojox.jsonPath.tests.module");

try{
	dojo.require("dojox.jsonPath.tests.jsonPath");
}catch(e){
	doh.debug(e);
}


dojo.provide("dojox.storage");
dojo.require("dojox.storage._common");
